import { useState, useEffect, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import { Bike, Car as CarIcon, Zap, Leaf, MapPin, Navigation, Search, Clock, Route as RouteIcon, CheckCircle2, X, ReceiptText, ShieldCheck, User, Mail, Lock, LogIn, AlertCircle } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine';

const createMarkerIcon = (color: string) => new L.DivIcon({
  html: `<div style="background-color: ${color}; width: 14px; height: 14px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 10px rgba(0,0,0,0.3);"></div>`,
  className: 'custom-pin',
  iconSize: [14, 14],
});

const startIcon = createMarkerIcon('#10b981'); 
const endIcon = createMarkerIcon('#ef4444');   

const vehicleMapIcon = (type: string) => L.divIcon({
  html: `<div class="bg-white p-1.5 rounded-full shadow-lg border border-emerald-100 text-emerald-600 transition-all duration-1000 ease-linear hover:scale-110 flex items-center justify-center">
          ${
            type === '0' ? '🛵' : // Scooty
            type === '1' ? '🚲' : // Bike
            type === '2' ? '🛺' : // Auto (🛺 is the standard Auto Rickshaw emoji)
            '🚗'                  // Car
          }
         </div>`,
  className: 'fleet-icon',
  iconSize: [35, 35],
});


function Routing({ start, end, setTravelInfo }: any) {
  const map = useMap();
  useEffect(() => {
    if (!map || !start || !end) return;
    const routingControl = L.Routing.control({
      waypoints: [L.latLng(start[0], start[1]), L.latLng(end[0], end[1])],
      lineOptions: { styles: [{ color: '#10b981', weight: 6, opacity: 0.7 }], extendToWaypoints: true },
      show: false, 
      addWaypoints: false,
    }).on('routesfound', (e) => {
      const summary = e.routes[0].summary;
      setTravelInfo({ 
        distance: (summary.totalDistance / 1000).toFixed(1), 
        time: Math.round(summary.totalTime / 60) 
      });
    }).addTo(map);
    return () => { map.removeControl(routingControl); };
  }, [map, start, end]);
  return null;
}

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.length < 5 || password.length < 4) {
      setError('Please enter valid credentials');
      return;
    }
    navigate('/dashboard');
  };

  return (
    <div className="h-screen w-full flex bg-slate-50 font-sans">
      <div className="hidden lg:flex flex-1 bg-emerald-600 items-center justify-center p-20 relative overflow-hidden text-white">
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-emerald-500 rounded-full blur-3xl opacity-50"></div>
        <div className="z-10">
          <h1 className="text-7xl font-black italic tracking-tighter mb-6">ECO<br/>RIDE</h1>
          <p className="text-emerald-100 text-xl max-w-md leading-relaxed">Sustainable urban mobility at your fingertips. Join the future of transit.</p>
        </div>
      </div>
      
      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-sm">
          <div className="mb-10">
            <h2 className="text-3xl font-black text-gray-900 mb-2 tracking-tight">Login</h2>
            <p className="text-gray-400 text-sm font-medium">Ready for an eco-friendly ride?</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-5">
            {error && <div className="p-3 bg-red-50 text-red-500 text-xs rounded-xl flex items-center gap-2 font-bold"><AlertCircle size={14}/> {error}</div>}
            
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-400 uppercase ml-2 tracking-widest">Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" className="w-full pl-12 p-4 bg-gray-50 border-0 rounded-2xl outline-none focus:ring-2 ring-emerald-500/20 text-sm font-semibold" />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-400 uppercase ml-2 tracking-widest">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="w-full pl-12 p-4 bg-gray-50 border-0 rounded-2xl outline-none focus:ring-2 ring-emerald-500/20 text-sm font-semibold" />
              </div>
            </div>

            <button type="submit" className="w-full py-4.5 bg-gray-900 text-white font-black uppercase tracking-[0.2em] rounded-2xl shadow-xl hover:bg-emerald-600 transition-all active:scale-95 flex items-center justify-center gap-2">
              Login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}


function Dashboard() {
  const [selected, setSelected] = useState('0');
  const [pickupQuery, setPickupQuery] = useState('');
  const [destQuery, setDestQuery] = useState('');
  const [suggestions, setSuggestions] = useState({ type: '', data: [] });
  const [pickup, setPickup] = useState<[number, number] | null>(null);
  const [destination, setDestination] = useState<[number, number] | null>(null);
  const [travelInfo, setTravelInfo] = useState({ distance: '0', time: 0 });
  const [showFareDetails, setShowFareDetails] = useState(false);
  const [isBooked, setIsBooked] = useState(false);
  const [fleetPositions, setFleetPositions] = useState<any[]>([]);


  useEffect(() => {
    if (!pickup) return;
    const initialFleet = Array.from({ length: 4 }).map(() => ({
      lat: pickup[0] + (Math.random() - 0.5) * 0.015,
      lng: pickup[1] + (Math.random() - 0.5) * 0.015
    }));
    setFleetPositions(initialFleet);
    const interval = setInterval(() => {
      setFleetPositions(prev => prev.map(pos => ({
        lat: pos.lat + (Math.random() - 0.5) * 0.0006,
        lng: pos.lng + (Math.random() - 0.5) * 0.0006
      })));
    }, 2500);
    return () => clearInterval(interval);
  }, [pickup, selected]);

  const VEHICLES = [
    { name: 'Scooty', base: 40, perKm: 8, icon: <Zap size={22}/> },
    { name: 'Bike', base: 50, perKm: 12, icon: <Bike size={22}/> },
    { name: 'Auto', base: 60, perKm: 15, icon: <Zap size={22}/> },
    { name: 'Car', base: 95, perKm: 26, icon: <CarIcon size={22}/> }
  ];

  const currentVehicle = VEHICLES[Number(selected)];
  const distanceVal = parseFloat(travelInfo.distance);
  const fareBase = currentVehicle.base;
  const fareDistance = (distanceVal * currentVehicle.perKm);
  const totalPrice = (fareBase + fareDistance + (fareBase + fareDistance) * 0.05).toFixed(0);

  const fetchSuggestions = async (query: string, type: 'pickup' | 'dest') => {
    if (type === 'pickup') setPickupQuery(query); else setDestQuery(query);
    if (query.length > 3) {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${query}&limit=4`);
      const data = await res.json();
      setSuggestions({ type, data });
    } else { setSuggestions({ type: '', data: [] }); }
  };

  const selectLocation = (s: any, type: 'pickup' | 'dest') => {
    const coords: [number, number] = [parseFloat(s.lat), parseFloat(s.lon)];
    if (type === 'pickup') { setPickup(coords); setPickupQuery(s.display_name.split(',')[0]); }
    else { setDestination(coords); setDestQuery(s.display_name.split(',')[0]); }
    setSuggestions({ type: '', data: [] });
  };

  return (
    <div className="flex h-screen w-full bg-slate-50 font-sans overflow-hidden">
      <div className="w-full md:w-[420px] h-full bg-white shadow-2xl z-[1001] flex flex-col border-r border-gray-100">
        <div className="p-8 pb-4">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-black text-emerald-600 italic tracking-tighter uppercase underline decoration-emerald-200 decoration-4">Eco Ride</h1>
            <ShieldCheck className="text-emerald-500" size={24}/>
          </div>
          <div className="space-y-4 relative">
             <input value={pickupQuery} onChange={(e) => fetchSuggestions(e.target.value, 'pickup')} placeholder="Pickup" className="w-full pl-6 p-4 bg-gray-50 border-0 rounded-2xl outline-none text-sm font-semibold shadow-inner" />
             <input value={destQuery} onChange={(e) => fetchSuggestions(e.target.value, 'dest')} placeholder="Destination" className="w-full pl-6 p-4 bg-gray-50 border-0 rounded-2xl outline-none text-sm font-semibold shadow-inner focus:ring-2 ring-emerald-500/10" />
             {suggestions.data.length > 0 && (
               <div className="absolute top-[95%] left-0 right-0 bg-white shadow-2xl rounded-2xl border z-[1002] overflow-hidden">
                 {suggestions.data.map((s: any, i) => (
                   <div key={i} onClick={() => selectLocation(s, suggestions.type as any)} className="p-4 hover:bg-emerald-50 cursor-pointer text-xs border-b last:border-0">{s.display_name}</div>
                 ))}
               </div>
            )}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-8 py-4 space-y-3 custom-scrollbar">
          {VEHICLES.map((v, i) => (
            <div key={i} onClick={() => setSelected(String(i))} className={`p-4 rounded-[28px] border-2 transition-all cursor-pointer flex items-center justify-between ${selected === String(i) ? 'border-emerald-500 bg-emerald-50' : 'border-gray-50 bg-white hover:border-gray-100'}`}>
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-2xl ${selected === String(i) ? 'bg-emerald-500 text-white' : 'bg-gray-100 text-gray-400'}`}>{v.icon}</div>
                <h4 className="font-bold text-gray-800 text-sm tracking-tight">{v.name}</h4>
              </div>
              <p className="font-black text-gray-900 text-lg">₹{(v.base + (distanceVal * v.perKm)).toFixed(0)}</p>
            </div>
          ))}
        </div>
        <div className="p-8 flex flex-col gap-3 border-t border-gray-50 bg-white">
          <button onClick={() => setShowFareDetails(true)} disabled={!destination} className="w-full py-3.5 bg-white border-2 border-emerald-500 text-emerald-500 font-bold rounded-2xl flex items-center justify-center gap-2 hover:bg-emerald-50 transition-all">
            <ReceiptText size={18}/> Fare Breakdown
          </button>
          <button onClick={() => setIsBooked(true)} disabled={!destination} className={`w-full py-5 font-black text-xs uppercase tracking-[0.2em] rounded-2xl shadow-xl transition-all ${destination ? 'bg-gray-900 text-white hover:bg-emerald-600' : 'bg-gray-100 text-gray-300 shadow-none'}`}>
            Book {currentVehicle.name}
          </button>
        </div>
      </div>

      <div className="flex-1 relative z-10 bg-slate-200">
        <MapContainer center={[16.5062, 80.5085]} zoom={13} zoomControl={false} className="h-full w-full">
          <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" />
          {pickup && <Marker position={pickup} icon={startIcon} />}
          {destination && <Marker position={destination} icon={endIcon} />}
          {fleetPositions.map((pos, i) => <Marker key={i} position={[pos.lat, pos.lng]} icon={vehicleMapIcon(selected)} />)}
          <Routing start={pickup} end={destination} setTravelInfo={setTravelInfo} />
        </MapContainer>
        
        {distanceVal > 0 && (
          <div className="absolute top-8 right-8 z-[1000] bg-white/90 backdrop-blur-md p-4 rounded-3xl shadow-2xl border border-emerald-100 flex items-center gap-4 animate-in fade-in slide-in-from-top duration-500">
             <div className="bg-emerald-500 p-2.5 rounded-2xl text-white shadow-lg shadow-emerald-200"><Leaf size={20}/></div>
             <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">CO2 Savings</p>
                <p className="text-base font-black text-emerald-600">{(distanceVal * 0.12).toFixed(2)} kg saved</p>
             </div>
          </div>
        )}
      </div>

      {showFareDetails && (
        <div className="fixed inset-0 z-[2000] bg-black/40 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="bg-white p-8 rounded-[40px] shadow-2xl max-w-sm w-full relative border-t-8 border-emerald-500">
            <button onClick={() => setShowFareDetails(false)} className="absolute top-6 right-6 text-gray-400"><X size={24}/></button>
            <h3 className="text-xl font-black mb-6 italic flex items-center gap-2 tracking-tight underline decoration-emerald-200 decoration-4">Fare Breakdown</h3>
            <div className="space-y-4 mb-8 text-sm">
              <div className="flex justify-between text-gray-500"><span>Booking Fee</span><span className="font-bold text-gray-900">₹{fareBase}</span></div>
              <div className="flex justify-between text-gray-500"><span>Distance ({travelInfo.distance} km)</span><span className="font-bold text-gray-900">₹{fareDistance.toFixed(0)}</span></div>
              <div className="h-[1px] bg-gray-100 my-2"></div>
              <div className="flex justify-between text-lg font-black italic"><span>Total Price</span><span className="text-emerald-500 text-xl">₹{totalPrice}</span></div>
            </div>
          </div>
        </div>
      )}

      {isBooked && (
        <div className="fixed inset-0 z-[2000] bg-gray-900/60 backdrop-blur-md flex items-center justify-center p-6 text-center">
          <div className="bg-white p-10 rounded-[40px] shadow-2xl max-w-xs border-4 border-emerald-50 animate-in zoom-in duration-300">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner"><CheckCircle2 size={40} /></div>
            <h2 className="text-2xl font-black mb-2 italic uppercase">Ride Booked!</h2>
            <p className="text-gray-500 text-sm mb-8 font-medium">Your {currentVehicle.name} is on its way. Safety PIN: 7729.</p>
            <button onClick={() => setIsBooked(false)} className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-emerald-600 transition-all">Track Ride</button>
          </div>
        </div>
      )}
    </div>
  );
}


export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </Router>
  );
}